import os
import sys
import subprocess
import shutil

def run_cmd(cmd, cwd=None):
    print(f"--> Menjalankan: {' '.join(cmd)}")
    try:
        result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            return True, result.stdout, result.stderr
        else:
            print(f"[-] Gagal: {result.stderr.strip()}")
            return False, result.stdout, result.stderr
    except Exception as e:
        print(f"[-] Error: {e}")
        return False, "", str(e)

def main():
    if os.geteuid() != 0:
        print("[-] Skrip ini harus dijalankan dengan hak akses root (sudo).")
        sys.exit(1)

    script_path = os.path.realpath(__file__)
    src_dir = os.path.dirname(script_path)
    web_dir = os.path.join(src_dir, "web_monitor")
    
    print("\n=================================================================")
    print("   QoS CAKE Adaptive - LOCAL INSTALLER SCRIPT FOR STB ROUTER    ")
    print("=================================================================")
    
    print("\n=== LANGKAH 1: Menginstal Dependensi Sistem ===")
    run_cmd(["apt-get", "update"])
    run_cmd(["apt-get", "install", "-y", "python3", "python3-pip", "python3-flask", "iproute2", "dnsmasq", "iptables"])
    
    print("\n=== LANGKAH 2: Mengompilasi dan Memuat Modul Custom cake_mq ===")
    
    src_folder = os.path.join(src_dir, "src")
    makefile_path = os.path.join(src_folder, "Makefile")
    
    # Buat Makefile
    makefile_content = """obj-m += sch_cake.o
all:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(CURDIR) modules
clean:
\tmake -C /lib/modules/$(shell uname -r)/build M=$(CURDIR) clean
"""
    with open(makefile_path, "w") as f:
        f.write(makefile_content)
        
    # Patch utsrelease.h karena headers Armbian sering salah version magic
    uname_r = os.uname().release
    uts_file = f"/lib/modules/{uname_r}/build/include/generated/utsrelease.h"
    if os.path.exists(uts_file):
        import re
        with open(uts_file, "r") as f:
            content = f.read()
        if uname_r not in content:
            new_content = re.sub(r'"[^"]+"', f'"{uname_r}"', content)
            with open(uts_file, "w") as f:
                f.write(new_content)
            print(f"[*] Patching UTS_RELEASE di {uts_file} menjadi {uname_r} untuk memperbaiki Invalid Module Format.")

    print("[*] Mengompilasi modul sch_cake.c...")
    ok, stdout, stderr = run_cmd(["make", "clean"], cwd=src_folder)
    ok, stdout, stderr = run_cmd(["make"], cwd=src_folder)
    
    if not ok:
        print("[-] Kompilasi gagal! Pastikan linux-headers sudah terinstal.")
        sys.exit(1)
        
    print("[+] Kompilasi berhasil.")
    
    # Hapus modul lama jika ada
    run_cmd(["rmmod", "sch_cake"])
    
    # Load modul baru
    module_path = os.path.join(src_folder, "sch_cake.ko")
    ok, stdout, stderr = run_cmd(["insmod", module_path])
    
    if ok:
        print("[+] Modul kernel custom cake_mq berhasil dimuat!")
    else:
        print(f"[-] Gagal memuat modul kernel: {stderr.strip()}")
        sys.exit(1)

    print("\n=== LANGKAH 3: Menyalin Core Daemon & Web Monitor ke Sistem ===")
    
    # 1. Salin script daemon ke /usr/local/bin
    print("[*] Memasang cake_adaptive.py ke /usr/local/bin...")
    shutil.copy(os.path.join(src_dir, "src", "cake_adaptive.py"), "/usr/local/bin/cake_adaptive.py")
    os.chmod("/usr/local/bin/cake_adaptive.py", 0o755)

    # 2. Salin file service systemd
    print("[*] Memasang service unit ke /etc/systemd/system...")
    shutil.copy(os.path.join(src_dir, "src", "cake-adaptive.service"), "/etc/systemd/system/cake-adaptive.service")
    shutil.copy(os.path.join(src_dir, "src", "web-monitor.service"), "/etc/systemd/system/web-monitor.service")

    # 3. Salin source code Web Monitor Flask
    flask_dest = "/usr/local/share/qos-cake-monitor"
    if os.path.exists(flask_dest):
        shutil.rmtree(flask_dest)
    
    os.makedirs(os.path.join(flask_dest, "templates"), exist_ok=True)
    shutil.copy(os.path.join(web_dir, "app.py"), os.path.join(flask_dest, "app.py"))
    os.chmod(os.path.join(flask_dest, "app.py"), 0o755)
    
    shutil.copy(os.path.join(web_dir, "templates/index.html"), os.path.join(flask_dest, "templates/index.html"))
    print("[+] File Web Monitor Flask berhasil disalin!")

    # 4. Tulis file konfigurasi default /etc/cake_adaptive.conf jika belum ada
    config_file = "/etc/cake_adaptive.conf"
    if not os.path.exists(config_file):
        default_conf_str = '{\n    "interface": "eth0",\n    "ping_dest": "1.1.1.1",\n    "bandwidth": "150mbit",\n    "interval": 1.0,\n    "extra_opts": "diffserv4",\n    "qdisc_type": "cake",\n    "wan_interface": "auto",\n    "lan_ip": "192.168.10.1",\n    "lan_netmask": "255.255.255.0",\n    "dhcp_enabled": false,\n    "dhcp_start": "192.168.10.10",\n    "dhcp_end": "192.168.10.100"\n}'
        with open(config_file, "w") as f:
            f.write(default_conf_str)
        print("[+] Konfigurasi default dibuat di /etc/cake_adaptive.conf")

    print("\n=== LANGKAH 4: Konfigurasi Jaringan (Router) ===")
    sysctl_file = "/etc/sysctl.conf"
    with open(sysctl_file, "r") as f:
        sysctl_content = f.read()
    if "net.ipv4.ip_forward=1" not in sysctl_content.replace(" ", ""):
        with open(sysctl_file, "a") as f:
            f.write("\nnet.ipv4.ip_forward=1\n")
        print("[+] IP Forwarding diaktifkan permanen di /etc/sysctl.conf")
    run_cmd(["sysctl", "-p"])

    print("\n=== LANGKAH 5: Mendaftarkan & Menjalankan Service Systemd ===")
    run_cmd(["systemctl", "daemon-reload"])
    
    print("[*] Mengaktifkan & menjalankan service cake-adaptive...")
    run_cmd(["systemctl", "enable", "cake-adaptive"])
    run_cmd(["systemctl", "restart", "cake-adaptive"])

    print("[*] Mengaktifkan & menjalankan service web-monitor...")
    run_cmd(["systemctl", "enable", "web-monitor"])
    run_cmd(["systemctl", "restart", "web-monitor"])

    print("\n=================================================================")
    print("   PROSES INSTALASI DAN ATURAN QOS CAKE ADAPTIVE SELESAI!")
    print("=================================================================")
    print("Dashboard Web Monitor sekarang berjalan langsung di STB.")
    print("Dapat diakses melalui browser Anda di:")
    print("  --> http://localhost:5000  (atau melalui IP STB Anda di port 5000)")
    print("\nLayanan background aktif:")
    print("  1. cake-adaptive  : Daemon auto-RTT (latency controller)")
    print("  2. web-monitor    : Monitoring Dashboard & Bandwidth Limiter")
    print("=================================================================\n")

if __name__ == "__main__":
    main()
